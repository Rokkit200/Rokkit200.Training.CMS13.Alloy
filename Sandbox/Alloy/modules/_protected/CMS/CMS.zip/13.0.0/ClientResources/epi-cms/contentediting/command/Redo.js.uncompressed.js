define("epi-cms/contentediting/command/Redo", [
    "dojo/_base/declare",
    "epi-cms/contentediting/command/_ContentCommandBase",
    "epi/i18n!epi/cms/nls/episerver.shared.action"
], function (declare, _ContentCommandBase, resource) {
    return declare([_ContentCommandBase], {
        name: "redo",
        isAvailable: false,
        canExecute: false,
        tooltip: resource.redo,
        label: resource.redo,
        propertiesToWatch: ["hasRedoSteps"],
        _execute: function () {
            this.model.redo();
        },
        _onModelChange: function () {
            this.inherited(arguments);
            this.set("isAvailable", !this.model.contentData.capabilities.isExperience);
        },
        _onPropertyChanged: function () {
            this.set("canExecute", this.model.hasRedoSteps);
        }
    });
});
