define(["exports","./content-binding-service_2","./verification-token-setter_2"],function(i,e,n){"use strict";i.getBindingDefinitions=e.getBindingDefinitions,i.getBindingObject=e.getBindingObject,i.updateBinding=e.updateBinding,Object.defineProperty(i,Symbol.toStringTag,{value:"Module"})});
//# sourceMappingURL=content-binding-service.js.map
