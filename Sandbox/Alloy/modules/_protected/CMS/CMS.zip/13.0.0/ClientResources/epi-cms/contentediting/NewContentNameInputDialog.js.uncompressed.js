require({cache:{
'url:epi-cms/contentediting/templates/NewContentNameInputDialog.html':"<div class=\"epi-formContainer\">\n    <div data-dojo-attach-point=\"messageNode\"></div>\n    <br />\n    <div>\n        <label data-dojo-attach-point=\"contentNameLabelNode\">\n            ${nameLabel}\n            <span class=\"epi-required-indicator dijitInline dijitReset\"></span>\n        </label>\n        <input type=\"text\" size=\"40\" maxlength=\"255\"  data-dojo-attach-point=\"contentNameTextbox\" data-dojo-type=\"dijit/form/ValidationTextBox\"\n                data-dojo-props=\"required: true, trim:true, selectOnClick: true\"\n                data-dojo-attach-event=\"onBlur: _onBlurVerifyContent\"\n                missingMessage: \"${res.errormessage.missingmessage}\" />\n    </div>\n</div>\n"}});
define("epi-cms/contentediting/NewContentNameInputDialog", [
    // Dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/dom-style",
    "dojo/keys",
    // Dijit
    "dijit/_CssStateMixin",
    "dijit/_Widget",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
    "dijit/form/TextBox",
    // EPi Framework
    "epi/shell/widget/dialog/_DialogContentMixin",
    "epi/shell/widget/_ModelBindingMixin",
    "epi/shell/widget/_ActionProviderWidget",
    // Template
    "dojo/text!./templates/NewContentNameInputDialog.html",
    // Resource
    "epi/i18n!epi/cms/nls/episerver.cms.widget.newcontentnamedialog",
    "epi/i18n!epi/shell/ui/nls/episerver.shared"
], function (
// Dojo
declare, lang, domStyle, keys, 
// Dijit
_CssStateMixin, _Widget, _TemplatedMixin, _WidgetsInTemplateMixin, _TextBox, 
// EPi Framework
_DialogContentMixin, _ModelBindingMixin, _ActionProviderWidget, 
// Template
template, 
// Resource
res, sharedResources) {
    return declare([_Widget, _TemplatedMixin, _WidgetsInTemplateMixin, _ActionProviderWidget, _DialogContentMixin, _CssStateMixin], {
        // tags:
        //      internal
        templateString: template,
        res: res,
        defaultContentName: null,
        message: null,
        title: null,
        nameLabel: sharedResources.header.name,
        _setMessageAttr: { node: "messageNode", type: "innerHTML" },
        postMixInProperties: function () {
            this.inherited(arguments);
            this.message = lang.replace(this.res.warningtext, {
                defaultname: this.defaultContentName
            });
            this._set("message", this.message);
            this.title = res.title;
        },
        postCreate: function () {
            this.inherited(arguments);
            this.contentNameTextbox.set("value", this.defaultContentName);
            this.contentNameTextbox.on("keyup", lang.hitch(this, function (evt) {
                var isValid = this.contentNameTextbox.isValid();
                if (evt.keyCode === keys.ENTER && isValid) {
                    this.executeDialog();
                }
            }));
            this.on("focus", lang.hitch(this, function () {
                this.contentNameTextbox.textbox.select();
            }));
        },
        _getValueAttr: function () {
            return this.contentNameTextbox.get("value");
        },
        _onBlurVerifyContent: function () {
            // summary:
            //    check if the textfield content is empty on blur,
            //    set to default value if it is.
            //
            // tags:
            //    private
            if (this.contentNameTextbox.get("value") === "") {
                this.contentNameTextbox.set("value", this.defaultContentName);
            }
        },
        getActions: function () {
            // summary:
            //      Overridden from _ActionProvider to get the select current content action added to the containing widget
            //
            // returns:
            //      An array contining a select page action definition, if it is not a shared block
            this._actions = [
                {
                    name: "cancel",
                    label: sharedResources.action.cancel,
                    settings: { type: "button", "class": "epi-plain-button" },
                    action: lang.hitch(this, function () {
                        this.cancelDialog();
                    })
                },
                {
                    name: "ok",
                    label: sharedResources.action.ok,
                    settings: { type: "button", "class": "Salt" },
                    action: lang.hitch(this, function () {
                        if (this.contentNameTextbox.isValid()) {
                            this.executeDialog();
                        }
                        else {
                            this.contentNameTextbox.focus();
                        }
                    })
                }
            ];
            return this._actions;
        }
    });
});
