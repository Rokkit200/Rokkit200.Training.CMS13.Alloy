define("epi-cms/contentediting/command/Undo", [
    "dojo/_base/declare",
    "epi-cms/contentediting/command/_ContentCommandBase",
    "epi/i18n!epi/cms/nls/episerver.shared.action"
], function (declare, _ContentCommandBase, resource) {
    return declare([_ContentCommandBase], {
        name: "undo",
        isAvailable: false,
        canExecute: false,
        tooltip: resource.undo,
        label: resource.undo,
        propertiesToWatch: ["hasUndoSteps"],
        _execute: function () {
            this.model.undo();
        },
        _onModelChange: function () {
            this.inherited(arguments);
            this.set("isAvailable", !this.model.contentData.capabilities.isExperience);
        },
        _onPropertyChanged: function () {
            this.set("canExecute", this.model.hasUndoSteps);
        }
    });
});
