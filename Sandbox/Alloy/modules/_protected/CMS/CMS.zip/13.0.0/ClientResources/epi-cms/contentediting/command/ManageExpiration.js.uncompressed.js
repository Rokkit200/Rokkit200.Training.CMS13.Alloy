define("epi-cms/contentediting/command/ManageExpiration", [
    // Dojo
    "dojo/_base/connect",
    "dojo/_base/declare",
    "dojo/on",
    "dojo/topic",
    "dojo/when",
    // EPi CMS
    "epi/dependency",
    "epi-cms/contentediting/section-visibility",
    "epi-cms/contentediting/ExpirationDialog",
    "epi-cms/contentediting/viewmodel/ExpirationDialogViewModel",
    "epi-cms/contentediting/ContentActionSupport",
    "epi-cms/contentediting/DialogPositionAdjust",
    // EPi Framework
    "epi/shell/command/_Command",
    "epi/shell/DialogService",
    "epi/shell/widget/dialog/Dialog",
    "epi/shell/DestroyableByKey",
    // Resources
    "epi/i18n!epi/cms/nls/episerver.cms.widget.expirationeditor",
    "epi/i18n!epi/nls/episerver.shared"
], function (
// Dojo
connect, declare, on, topic, when, 
// EPi CMS
dependency, getSectionVisibility, ExpirationDialog, ExpirationDialogViewModel, ContentActionSupport, DialogPositionAdjust, 
// EPi Framework
_Command, dialogService, Dialog, DestroyableByKey, 
// Resources
resources, sharedResources) {
    return declare([_Command, DestroyableByKey], {
        // summary:
        //      Displays the manage expiration dialog for the current content.
        //
        // tags:
        //      internal xproduct
        label: resources.dialogtitle,
        tooltip: resources.dialogtitle,
        viewModel: null,
        cssClass: "epi-chromelessButton epi-visibleLink",
        // expirationDialogClass: [public] Function
        //      The constructor function for the expiration dialog
        expirationDialogClass: ExpirationDialog,
        // expirationDialogViewModelClass: [public] Function
        //      The constructor function for the expiration dialog view model
        expirationDialogViewModelClass: ExpirationDialogViewModel,
        postscript: function () {
            this.inherited(arguments);
            this._dialogPositionAdjust = new DialogPositionAdjust();
            this.own(this._dialogPositionAdjust);
            // Update the label initially
            this._updateLabel();
        },
        _updateLabel: function () {
            var archivingEnabled = getSectionVisibility("archiving");
            this.set("label", archivingEnabled ? resources.dialogtitle : resources.expiration);
            // update the tooltip only when it's set
            if (this.get("tooltip")) {
                this.set("tooltip", archivingEnabled ? resources.dialogtitle : resources.expiration);
            }
        },
        _execute: function () {
            // summary:
            //		Toggles the value of the given property on the model.
            // tags:
            //		protected
            this._getViewModel().then(function (dialogViewModel) {
                if (!dialogViewModel) {
                    return;
                }
                var content = new this.expirationDialogClass({ model: dialogViewModel });
                var archivingEnabled = getSectionVisibility("archiving");
                this._dialog = new Dialog({
                    defaultActionsVisible: false,
                    confirmActionText: sharedResources.action.save,
                    content: content,
                    title: archivingEnabled ? resources.dialogtitle : resources.expiration,
                    dialogClass: "epi-dialog-portrait"
                });
                this.own(this._dialog);
                this._dialogPositionAdjust.adjustDialogPosition(this._dialog, function () {
                    this._dialog.resize();
                }.bind(this));
                this._dialog.own(on.once(this._dialog, "execute", function (value) {
                    var model = this.get("model");
                    model.saveAndPublishProperty("iversionable_expire", value, ContentActionSupport.saveAction.SkipValidation).then(function () {
                        topic.publish("update-expiration", model);
                    });
                }.bind(this)));
                this._dialog.own(on(this._dialog, "hide", function () {
                    this._dialogPositionAdjust.cleanup();
                }.bind(this)));
                this._dialog.show();
            }.bind(this));
        },
        _getViewModel: function () {
            this._store = this._store || dependency.resolve("epi.storeregistry").get("epi.cms.contentdata");
            var model = this.get("model");
            if (!model || !model.contentData) {
                return null;
            }
            return when(this._store.get(model.contentLink)).then(function (contentData) {
                return when(model.getPropertyMetaData("iversionable_expire"))
                    .then(function (metadata) {
                    var properties = contentData.properties, expireBlock = properties.iversionable_expire;
                    var viewModel = new this.expirationDialogViewModelClass({
                        metadata: metadata,
                        contentLink: model.contentLink,
                        contentData: model.contentData,
                        contentName: model.contentData.name,
                        value: expireBlock,
                        minimumExpireDate: properties.iversionable_startpublish
                    });
                    return viewModel;
                }.bind(this)).otherwise(function (res) {
                    if (res && res.status === 409) {
                        dialogService.alert(sharedResources.messages.unexpectederror);
                    }
                    return null;
                });
            }.bind(this));
        },
        _onModelChange: function () {
            // summary:
            //		Updates canExecute after the model has been updated.
            // tags:
            //		protected
            var model = this.get("model");
            if (!model || !model.contentData) {
                this.set("canExecute", false);
                return;
            }
            var canExecute = model.canChangeContent() &&
                ContentActionSupport.hasAccess(model.contentData.accessMask, ContentActionSupport.accessLevel.Publish); // Ensure the user has Publish access right
            // Command is not available until the metadata resolves
            this.set("canExecute", canExecute);
            // Update the label when the model changes
            this._updateLabel();
        }
    });
});
