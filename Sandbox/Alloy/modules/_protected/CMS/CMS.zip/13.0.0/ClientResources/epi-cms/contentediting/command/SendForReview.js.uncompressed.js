define("epi-cms/contentediting/command/SendForReview", [
    "dojo/_base/declare",
    "epi-cms/contentediting/ContentActionSupport",
    "epi-cms/contentediting/command/_ChangeContentStatus",
    //Resources
    "epi/i18n!epi/cms/nls/episerver.cms.contentediting.toolbar.buttons"
], function (declare, ContentActionSupport, _ChangeContentStatus, resources) {
    return declare([_ChangeContentStatus], {
        // summary:
        //      Set the content as ready to publish
        //
        // tags:
        //      internal
        label: resources.sendforreview.label,
        executingLabel: resources.sendforreview.executinglabel,
        tooltip: resources.sendforreview.title,
        iconClass: "epi-iconCheckmark",
        action: ContentActionSupport.saveAction.CheckIn
    });
});
