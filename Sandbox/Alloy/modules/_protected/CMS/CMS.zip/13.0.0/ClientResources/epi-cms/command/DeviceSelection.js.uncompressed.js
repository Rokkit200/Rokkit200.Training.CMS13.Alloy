define("epi-cms/command/DeviceSelection", [
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/on",
    "epi/shell/DestroyableByKey",
    "epi/shell/command/OptionCommand",
    "epi-cms/command/_NonEditViewCommandMixin",
    "epi-cms/contentediting/viewmodel/DeviceSelectionSettingsModel"
], function (declare, lang, on, DestroyableByKey, OptionCommand, _NonEditViewCommandMixin, DeviceSelectionSettingsModel) {
    return declare([OptionCommand, _NonEditViewCommandMixin, DestroyableByKey], {
        // summary:
        //      Command providing the channel and resolution selection for the top menu
        // tags:
        //      internal
        iconClass: "epi-iconDevice",
        optionsProperty: "options",
        canExecute: true,
        active: false,
        _hasOptions: false,
        postscript: function () {
            this.inherited(arguments);
            if (!this.model) {
                this.set("model", new DeviceSelectionSettingsModel());
            }
            this.own(on(this.model, "optionsChanged", function (options) {
                this._hasOptions = options.length > 0;
                this.set("isAvailable", this._hasOptions);
                this.set("canExecute", this._hasOptions);
            }.bind(this)));
        },
        _updateFromModel: function () {
            // summary:
            //      Update the state of the command from the current model state
            //
            // tags: private
            this.set("label", this.model.get("label"));
            this.set("active", !!(this.model.get("resolution") || this.model.get("channel")));
        },
        _onModelChange: function () {
            // summary:
            //      Watches the model for property changes and updates our state accordingly
            this.inherited(arguments);
            var modelWatchKey = "_ChannelCommandModelWatch";
            this.destroyByKey(modelWatchKey);
            if (this.model) {
                this._updateFromModel();
                this.ownByKey(modelWatchKey, this.model.watch(lang.hitch(this, function (name, oldValue, newValue) {
                    if (["label", "resolution", "channel"].indexOf(name) !== -1) {
                        this._updateFromModel();
                    }
                })));
            }
        },
        _viewChanged: function (type, args, data) {
            this.inherited(arguments);
            if (data.viewConfiguration && data.viewConfiguration.availableFeatures &&
                data.viewConfiguration.availableFeatures.deviceSelection === false) {
                this.set("isAvailable", false);
                return;
            }
            if (!this._hasOptions) {
                this.set("isAvailable", false);
            }
            else if (data && data.hideView) {
                // hide the DeviceSelection icon if content has no view
                this.set("isAvailable", false);
            }
        }
    });
});
